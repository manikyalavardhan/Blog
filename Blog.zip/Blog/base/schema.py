import graphene
from graphene_django import DjangoObjectType
from .models import Post, Comment

class PostType(DjangoObjectType):
	class Meta:
		model = Post
		fields = "__all__"

class CommentType(DjangoObjectType):
	class Meta:
		model = Comment
		fields = "__all__"

class Query(graphene.ObjectType):
	posts = graphene.List(PostType, id=graphene.Int())
	comments = graphene.List(CommentType, id=graphene.Int())

	def resolve_posts(root, info, **kwargs):
		if kwargs:
			return Post.objects.filter(id= kwargs['id'])	
		else:
			return Post.objects.all()

	def resolve_comments(root, info, id):
		return Comment.objects.filter(post_id = id)





class CreatePostMutation(graphene.Mutation):
	class Arguments:
		title = graphene.String(required=True)
		description = graphene.String()
		author = graphene.String(required=True)

	post = graphene.Field(PostType)

	@classmethod
	def mutate(cls,root,info,title,description,author):
		post = Post(title=title, description=description, author= author)
		post.save()
		return CreatePostMutation(post=post)

class UpdatePostMutation(graphene.Mutation):
	class Arguments:
		id = graphene.ID(required=True)
		title = graphene.String()
		description = graphene.String()
		author = graphene.String()

	post = graphene.Field(PostType)

	@classmethod
	def mutate(cls,root,info,id,title,description,author):
		post = Post.objects.get(id=id)
		post.title = title
		post.description = description
		post.author = author
		post.save()
		return UpdatePostMutation(post=post)

class CreateComment(graphene.Mutation):
	class Arguments:
		post_id = graphene.Int(required=True)
		text = graphene.String(required=True)
		author = graphene.String(required=True)

	comment = graphene.Field(CommentType)

	@classmethod
	def mutate(cls,root,info,post_id,text,author):
		post_inst = Post.objects.get(id=post_id)
		comment = Comment(post=post_inst,text=text,author=author)
		comment.save()
		return CreateComment(comment=comment)

class DeleteComment(graphene.Mutation):
	class Arguments:
		id = graphene.ID(required=True)

	comment = graphene.Field(CommentType)

	@classmethod
	def mutate(cls,root,info,id):
		comment = Comment.objects.get(id=id)
		comment.delete()
		return 	DeleteComment(comment=comment)

class Mutation(graphene.ObjectType):
	create_post = CreatePostMutation.Field()
	update_post = UpdatePostMutation.Field()
	create_comment = CreateComment.Field()
	delete_comment = DeleteComment.Field()

schema = graphene.Schema(query = Query, mutation = Mutation)